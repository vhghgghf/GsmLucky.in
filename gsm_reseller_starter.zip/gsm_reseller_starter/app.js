const services = [
  {id:"SRV-101", icon:"⌁", en:"Device Diagnostics", hi:"डिवाइस जाँच", descEn:"Illustrative diagnostic request for devices you own or are authorized to service.", descHi:"अपने या अधिकृत डिवाइस के लिए उदाहरणात्मक जाँच अनुरोध।", price:49},
  {id:"SRV-102", icon:"⚙", en:"Software Support", hi:"सॉफ़्टवेयर सहायता", descEn:"General software troubleshooting and setup assistance.", descHi:"सामान्य सॉफ़्टवेयर समस्या और सेटअप सहायता।", price:99},
  {id:"SRV-103", icon:"▣", en:"Warranty Check Help", hi:"वारंटी जाँच सहायता", descEn:"Help finding the official manufacturer warranty-check page.", descHi:"निर्माता की आधिकारिक वारंटी जाँच वेबसाइट खोजने में सहायता।", price:29},
  {id:"SRV-104", icon:"✓", en:"Authorized Repair Request", hi:"अधिकृत रिपेयर अनुरोध", descEn:"Demo request for a repair provider authorized by the device owner.", descHi:"डिवाइस मालिक की अनुमति वाले रिपेयर प्रदाता के लिए डेमो अनुरोध।", price:149}
];
let language = localStorage.getItem("rudraLanguage") || "en";
let orders = JSON.parse(localStorage.getItem("rudraDemoOrders") || "[]");
let mode = "login";
const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();

function tr(en, hi) { return language === "hi" ? hi : en; }
function applyLanguage() {
  document.documentElement.lang = language === "hi" ? "hi" : "en";
  document.querySelectorAll("[data-en][data-hi]").forEach(el => {
    if (el.tagName !== "INPUT") el.textContent = el.dataset[language];
  });
  document.querySelectorAll("[data-en-placeholder][data-hi-placeholder]").forEach(el => {
    el.placeholder = el.dataset[language === "hi" ? "hiPlaceholder" : "enPlaceholder"];
  });
  $("langToggle").textContent = language === "en" ? "हिंदी" : "English";
  $("loginOpen").textContent = tr("Login", "लॉगिन");
  $("registerOpen").textContent = tr("Create Account", "अकाउंट बनाएँ");
  $("clearOrders").textContent = tr("Clear demo data", "डेमो डेटा हटाएँ");
  renderServices(); renderOrders();
}
function renderServices() {
  const q = $("serviceSearch").value.trim().toLocaleLowerCase();
  const visible = services.filter(s => `${s.en} ${s.hi} ${s.descEn} ${s.descHi}`.toLocaleLowerCase().includes(q));
  $("serviceCount").textContent = services.length;
  $("serviceGrid").innerHTML = visible.map(s => `
    <article class="service-card">
      <div class="service-icon" aria-hidden="true">${s.icon}</div>
      <h3>${language === "hi" ? s.hi : s.en}</h3>
      <p>${language === "hi" ? s.descHi : s.descEn}</p>
      <div class="service-bottom"><span class="price">₹${s.price}<small>${tr("sample price", "नमूना कीमत")}</small></span>
      <button class="order-btn" data-order="${s.id}">${tr("Demo order +", "डेमो ऑर्डर +")}</button></div>
    </article>`).join("");
  document.querySelectorAll("[data-order]").forEach(btn => btn.addEventListener("click", () => placeOrder(btn.dataset.order)));
}
function renderOrders() {
  $("orderCount").textContent = orders.length;
  if (!orders.length) {
    $("ordersBody").innerHTML = `<tr><td colspan="5" class="empty">${tr("No demo orders yet. Choose a service above.", "अभी कोई डेमो ऑर्डर नहीं है। ऊपर से सेवा चुनें।")}</td></tr>`;
    return;
  }
  $("ordersBody").innerHTML = orders.map(o => `<tr><td>${o.id}</td><td>${language === "hi" ? o.serviceHi : o.serviceEn}</td><td>${o.date}</td><td>₹${o.amount.toFixed(2)}</td><td><span class="status">${tr("Demo only", "केवल डेमो")}</span></td></tr>`).join("");
}
function placeOrder(id) {
  const s = services.find(item => item.id === id);
  if (!s) return;
  const order = {id:"DEMO-" + Date.now().toString().slice(-7), serviceEn:s.en, serviceHi:s.hi, date:new Date().toLocaleDateString(), amount:s.price};
  orders.unshift(order);
  localStorage.setItem("rudraDemoOrders", JSON.stringify(orders));
  renderOrders();
  showToast(tr("Demo order created in this browser only.", "डेमो ऑर्डर केवल इसी ब्राउज़र में बनाया गया।"));
  $("orders").scrollIntoView({behavior:"smooth", block:"start"});
}
function showToast(message) {
  $("toast").textContent = message; $("toast").classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => $("toast").classList.remove("show"), 2800);
}
function openAccount(nextMode) {
  mode = nextMode;
  $("dialogTitle").textContent = tr(nextMode === "login" ? "Login" : "Create account", nextMode === "login" ? "लॉगिन" : "अकाउंट बनाएँ");
  $("dialogEyebrow").textContent = tr("DEMO ACCOUNT", "डेमो अकाउंट");
  $("accountSubmit").textContent = tr(nextMode === "login" ? "Continue" : "Preview registration", nextMode === "login" ? "आगे बढ़ें" : "रजिस्ट्रेशन प्रीव्यू");
  $("userName").style.display = nextMode === "login" ? "none" : "block";
  $("accountForm").querySelector('label[for="userName"]').style.display = nextMode === "login" ? "none" : "block";
  $("formMessage").textContent = "";
  $("accountDialog").showModal();
}
$("loginOpen").addEventListener("click", () => openAccount("login"));
$("registerOpen").addEventListener("click", () => openAccount("register"));
$("langToggle").addEventListener("click", () => {
  language = language === "en" ? "hi" : "en";
  localStorage.setItem("rudraLanguage", language); applyLanguage();
});
$("serviceSearch").addEventListener("input", renderServices);
$("clearOrders").addEventListener("click", () => {
  orders = []; localStorage.removeItem("rudraDemoOrders"); renderOrders();
  showToast(tr("Demo order history cleared.", "डेमो ऑर्डर हिस्ट्री हटा दी गई।"));
});
$("accountForm").addEventListener("submit", event => {
  event.preventDefault();
  const email = $("userEmail").value.trim();
  if (!email || $("userPassword").value.length < 6) {
    $("formMessage").textContent = tr("Enter a valid email and a password of at least 6 characters.", "सही ईमेल और कम से कम 6 अक्षरों का पासवर्ड डालें।");
    return;
  }
  $("accountDialog").close();
  showToast(tr("Demo only: no account was created and no data was sent.", "केवल डेमो: अकाउंट नहीं बना और डेटा कहीं नहीं भेजा गया।"));
  $("accountForm").reset();
});
applyLanguage();